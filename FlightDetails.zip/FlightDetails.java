package com.model;

import javax.persistence.*;

@Entity  
@Table(name="FLIGHTS.FLIGHT_DETAILS")
public class FlightDetails {
	

	public FlightDetails(String flightDetId, String flightCd, int economic,
			int business, int first, String departureTime, Flight flight) {
		super();
		this.flightDetId = flightDetId;
		this.flightCd = flightCd;
		this.economic = economic;
		this.business = business;
		this.first = first;
		this.departureTime = departureTime;
//		this.flight = flight;
	}
	public FlightDetails(){
		super();
	}
	
	@Id
	@Column(name="FLIGHT_DET_ID")
	private String flightDetId;
	
	@Column(name="FLIGHT_CD")
	private String flightCd;
	

	@Column(name="ECONOMIC")
	private int economic;
	
	@Column(name="BUSINESS")
	private int business;
	
	@Column(name="FIRST_CLASS")
	private int first;
	
	@Column(name="DEPARTURE_TIME")
	private String departureTime;
	
	  //  @ManyToOne  
	  //  @JoinColumn(name="FLIGHT_ID")
	// private Flight flight;
	
	 
	 
	 
	//public Flight getFlight() {
	//	return flight;
	//}
	//public void setFlight(Flight flight) {
	//	this.flight = flight;
	//}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String destination) {
		this.departureTime = destination;
	}
	public String getFlightDetId() {
		return flightDetId;
	}
	public void setFlightId(String flightDetId) {
		this.flightDetId = flightDetId;
	}
	public int getEconomic() {
		return economic;
	}
	public void setEconomic(int economic) {
		this.economic = economic;
	}
	public int getBusiness() {
		return business;
	}
	public void setBusiness(int business) {
		this.business = business;
	}
	public int getFirst() {
		return first;
	}
	public void setFirst(int first) {
		this.first = first;
	}
	
	
	public String getFlightCd() {
		return flightCd;
	}
	public void setFlightCd(String flightCd) {
		this.flightCd = flightCd;
	}

}

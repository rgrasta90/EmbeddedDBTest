package com.model;

import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity  
@Table(name="FLIGHTS.FLIGHT")
public class Flight {
	
	public Flight(String flightId, String destination,
			List<FlightDetails> flightDetails) {
		super();
		this.flightId = flightId;
		this.destination = destination;
//		this.flightDetails = flightDetails;
	}
	
	public Flight(){
		super();
	}
	
	@Id
	@Column(name="FLIGHT_ID")
	private String flightId;

	@Column(name="DESTINATION")
	private String destination;

  //  @OneToMany(mappedBy="flight")
  //  private List<FlightDetails> flightDetails;
	
	
/*	public List<FlightDetails> getFlightDetails() {
		return flightDetails;
	}
	public void setFlightDetails(List flightDetails) {
		this.flightDetails = flightDetails;
	}*/
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}


}
